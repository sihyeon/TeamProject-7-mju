package Frame;

public class PFLauncher {

	public static void main(String[] args) {
		PFMainFrame frame = PFMainFrame.getUniqueMainFrame();
		frame.init();	//���α׷� ����
	}

}
